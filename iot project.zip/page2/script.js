



let powerChart, energyChart, historicalPowerChart, historicalEnergyChart;

function showTab(tab) {
  document.getElementById('live-tab').style.display = tab === 'live' ? 'block' : 'none';
  document.getElementById('historical-tab').style.display = tab === 'historical' ? 'block' : 'none';
  document.querySelectorAll('.tab').forEach(btn => btn.classList.remove('active'));
  document.querySelector('.tab:nth-child(' + (tab === 'live' ? '1' : '2') + ')').classList.add('active');
}

function generateDateLabels(startDate, endDate) {
  const labels = [];
  let current = new Date(startDate);
  const end = new Date(endDate);

  while (current <= end) {
    labels.push(current.toISOString().split('T')[0]);
    current.setDate(current.getDate() + 1);
  }
  return labels;
}

function generateHistoricalData() {
  const start = document.getElementById("start-date").value;
  const end = document.getElementById("end-date").value;

  if (!start || !end) {
    alert("Please select both start and end dates.");
    return;
  }

  const labels = generateDateLabels(start, end);
  const powerData = []; // سيتم تعبئتها من API
  const energyData = [];

  if (historicalPowerChart) historicalPowerChart.destroy();
  if (historicalEnergyChart) historicalEnergyChart.destroy();

  const powerCtx = document.getElementById("historicalPowerChart").getContext("2d");
  const energyCtx = document.getElementById("historicalEnergyChart").getContext("2d");

  historicalPowerChart = new Chart(powerCtx, {
    type: "line",
    data: {
      labels: labels,
      datasets: [{
        label: "Power (kW)",
        data: powerData,
        borderColor: "#007bff",
        fill: false,
        tension: 0.4
      }]
    },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        y: { display: false, grid: { display: false }, ticks: { display: false } },
        x: { display: true, grid: { display: false }, ticks: { display: true } }
      }
    }
  });

  historicalEnergyChart = new Chart(energyCtx, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [{
        label: "Energy (kWh)",
        data: energyData,
        backgroundColor: "#007bff"
      }]
    },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        y: { display: false, grid: { display: false }, ticks: { display: false } },
        x: { display: true, grid: { display: false }, ticks: { display: true } }
      }
    }
  });
}

window.onload = function () {
  const powerCtx = document.getElementById('powerChart').getContext('2d');
  const energyCtx = document.getElementById('energyChart').getContext('2d');

  powerChart = new Chart(powerCtx, {
    type: 'line',
    data: {
      labels: ['00:00', '00:05', '00:10', '00:15', '00:20', '00:25', '00:30'],
      datasets: [{ data: [], borderColor: '#007bff', tension: 0.4, fill: false }]
    },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        y: { display: false, grid: { display: false }, ticks: { display: false } },
        x: { display: true, grid: { display: false }, ticks: { display: true } }
      }
    }
  });

  energyChart = new Chart(energyCtx, {
    type: 'bar',
    data: {
      labels: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00', '24:00'],
      datasets: [{ data: [], backgroundColor: '#007bff' }]
    },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        y: { display: false, grid: { display: false }, ticks: { display: false } },
        x: { display: true, grid: { display: false }, ticks: { display: true } }
      }
    }
  });

  // يمكنك هنا جلب البيانات الحية من API مثلاً:
  // fetchLiveData();
  // setInterval(fetchLiveData, 5000);
};
