



// let powerChart, energyChart, historicalPowerChart, historicalEnergyChart;

// function showTab(tab) {
//   document.getElementById('live-tab').style.display = tab === 'live' ? 'block' : 'none';
//   document.getElementById('historical-tab').style.display = tab === 'historical' ? 'block' : 'none';

//   const tabs = document.querySelectorAll('.tab');
//   tabs.forEach(btn => btn.classList.remove('active'));

//   const selectedTab = tab === 'live' ? tabs[0] : tabs[1];
//   selectedTab.classList.add('active');

//   // ✅ تحريك الخط الأزرق تحت التاب النشط
//   const underline = document.querySelector('.tabs-underline');
//   underline.style.width = selectedTab.offsetWidth + 'px';
//   underline.style.left = selectedTab.offsetLeft + 'px';
// }

// function getRandomData(count, min = 1, max = 2) {
//   return Array.from({ length: count }, () => (Math.random() * (max - min) + min).toFixed(2));
// }

// function generateLiveData() {
//   if (powerChart && energyChart) {
//     const powerData = getRandomData(7, 1, 2);
//     const energyData = getRandomData(7, 10, 16);

//     powerChart.data.datasets[0].data = powerData;
//     energyChart.data.datasets[0].data = energyData;

//     powerChart.update();
//     energyChart.update();

//     // تحديث النصوص الخاصة بـ live
//     const latestPower = powerData[powerData.length - 1];
//     const powerPercent = (Math.random() * 10).toFixed(1);

//     const latestEnergy = energyData[energyData.length - 1];
//     const energyPercent = (Math.random() * 10).toFixed(1);

//     document.getElementById("livePowerValue").textContent = `${latestPower} kW`;
//     document.getElementById("livePowerChange").textContent = `Live +${powerPercent}%`;

//     document.getElementById("liveEnergyValue").textContent = `${latestEnergy} kWh`;
//     document.getElementById("liveEnergyChange").textContent = `Live +${energyPercent}%`;
//   }
// }

// function generateDateLabels(startDate, endDate) {
//   const labels = [];
//   let current = new Date(startDate);
//   const end = new Date(endDate);

//   while (current <= end) {
//     labels.push(current.toISOString().split('T')[0]);
//     current.setDate(current.getDate() + 1);
//   }
//   return labels;
// }

// function generateHistoricalData() {
//   const start = document.getElementById("start-date").value;
//   const end = document.getElementById("end-date").value;

//   if (!start || !end) {
//     alert("Please select both start and end dates.");
//     return;
//   }

//   const labels = generateDateLabels(start, end);
//   const powerData = getRandomData(labels.length, 1, 2);
//   const energyData = getRandomData(labels.length, 10, 16);

//   if (historicalPowerChart) historicalPowerChart.destroy();
//   if (historicalEnergyChart) historicalEnergyChart.destroy();

//   const powerCtx = document.getElementById("historicalPowerChart").getContext("2d");
//   const energyCtx = document.getElementById("historicalEnergyChart").getContext("2d");

//   historicalPowerChart = new Chart(powerCtx, {
//     type: "line",
//     data: {
//       labels: labels,
//       datasets: [{
//         label: "Power (kW)",
//         data: powerData,
//         borderColor: "#007bff",
//         fill: false,
//         tension: 0.4
//       }]
//     },
//     options: {
//       plugins: { legend: { display: false } },
//       scales: {
//         y: { display: false, grid: { display: false }, ticks: { display: false } },
//         x: { display: true, grid: { display: false }, ticks: { display: true } }
//       }
//     }
//   });

//   historicalEnergyChart = new Chart(energyCtx, {
//     type: "bar",
//     data: {
//       labels: labels,
//       datasets: [{
//         label: "Energy (kWh)",
//         data: energyData,
//         backgroundColor: "#007bff"
//       }]
//     },
//     options: {
//       plugins: { legend: { display: false } },
//       scales: {
//         y: { display: false, grid: { display: false }, ticks: { display: false } },
//         x: { display: true, grid: { display: false }, ticks: { display: true } }
//       }
//     }
//   });

//   // تحديث النصوص الخاصة بـ historical
//   const latestPower = powerData[powerData.length - 1];
//   const powerPercent = (Math.random() * 10).toFixed(1);

//   const latestEnergy = energyData[energyData.length - 1];
//   const energyPercent = (Math.random() * 10).toFixed(1);

//   document.getElementById("histPowerValue").textContent = `${latestPower} kW`;
//   document.getElementById("histPowerChange").textContent = `Today +${powerPercent}%`;

//   document.getElementById("histEnergyValue").textContent = `${latestEnergy} kWh`;
//   document.getElementById("histEnergyChange").textContent = `Today +${energyPercent}%`;
// }

// window.onload = function () {
//   const powerCtx = document.getElementById('powerChart').getContext('2d');
//   const energyCtx = document.getElementById('energyChart').getContext('2d');

//   powerChart = new Chart(powerCtx, {
//     type: 'line',
//     data: {
//       labels: ['00:00', '00:05', '00:10', '00:15', '00:20', '00:25', '00:30'],
//       datasets: [{ data: getRandomData(7), borderColor: '#007bff', tension: 0.4, fill: false }]
//     },
//     options: {
//       plugins: { legend: { display: false } },
//       scales: {
//         y: { display: false, grid: { display: false }, ticks: { display: false } },
//         x: { display: true, grid: { display: false }, ticks: { display: true } }
//       }
//     }
//   });

//   energyChart = new Chart(energyCtx, {
//     type: 'bar',
//     data: {
//       labels: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00', '24:00'],
//       datasets: [{ data: getRandomData(7, 10, 16), backgroundColor: '#007bff' }]
//     },
//     options: {
//       plugins: { legend: { display: false } },
//       scales: {
//         y: { display: false, grid: { display: false }, ticks: { display: false } },
//         x: { display: true, grid: { display: false }, ticks: { display: true } }
//       }
//     }
//   });

//   // تحريك underline على التاب النشط عند تحميل الصفحة
//   const activeTab = document.querySelector('.tab.active');
//   const underline = document.querySelector('.tabs-underline');
//   underline.style.width = activeTab.offsetWidth + 'px';
//   underline.style.left = activeTab.offsetLeft + 'px';

//   setInterval(generateLiveData, 5000);
//   generateLiveData();
// };







let powerChart, energyChart, historicalPowerChart, historicalEnergyChart;

function showTab(tab) {
  document.getElementById('live-tab').style.display = tab === 'live' ? 'block' : 'none';
  document.getElementById('historical-tab').style.display = tab === 'historical' ? 'block' : 'none';

  const tabs = document.querySelectorAll('.tab');
  tabs.forEach(btn => btn.classList.remove('active'));

  const selectedTab = tab === 'live' ? tabs[0] : tabs[1];
  selectedTab.classList.add('active');

  const underline = document.querySelector('.tabs-underline');
  underline.style.width = selectedTab.offsetWidth + 'px';
  underline.style.left = selectedTab.offsetLeft + 'px';
}

// تحضير دالة لجلب بيانات live من الحساس (أنت هتضيف الكود الفعلي لاحقًا)
async function fetchLiveData() {
  try {
    // TODO: استبدل هذا الجزء بجلب البيانات من الحساس
    const powerData = [];   // مثال: [1.1, 1.2, ...]
    const energyData = [];  // مثال: [12, 13, ...]

    powerChart.data.datasets[0].data = powerData;
    energyChart.data.datasets[0].data = energyData;

    powerChart.update();
    energyChart.update();

    const latestPower = powerData[powerData.length - 1];
    const latestEnergy = energyData[energyData.length - 1];

    document.getElementById("livePowerValue").textContent = `${latestPower} kW`;
    document.getElementById("liveEnergyValue").textContent = `${latestEnergy} kWh`;

    document.getElementById("livePowerChange").textContent = `Live`;
    document.getElementById("liveEnergyChange").textContent = `Live`;

  } catch (error) {
    console.error("Error fetching live data:", error);
  }
}

function generateDateLabels(startDate, endDate) {
  const labels = [];
  let current = new Date(startDate);
  const end = new Date(endDate);

  while (current <= end) {
    labels.push(current.toISOString().split('T')[0]);
    current.setDate(current.getDate() + 1);
  }
  return labels;
}

// تحضير دالة لجلب بيانات historical من Supabase (أنت هتضيف الكود الفعلي لاحقًا)
async function generateHistoricalData() {
  const start = document.getElementById("start-date").value;
  const end = document.getElementById("end-date").value;

  if (!start || !end) {
    alert("Please select both start and end dates.");
    return;
  }

  try {
    // TODO: استبدل هذا الجزء بجلب البيانات من Supabase
    const labels = generateDateLabels(start, end);
    const powerData = [];   // مثال: [1.2, 1.5, ...]
    const energyData = [];  // مثال: [12, 13, ...]

    if (historicalPowerChart) historicalPowerChart.destroy();
    if (historicalEnergyChart) historicalEnergyChart.destroy();

    const powerCtx = document.getElementById("historicalPowerChart").getContext("2d");
    const energyCtx = document.getElementById("historicalEnergyChart").getContext("2d");

    historicalPowerChart = new Chart(powerCtx, {
      type: "line",
      data: {
        labels: labels,
        datasets: [{
          label: "Power (kW)",
          data: powerData,
          borderColor: "#007bff",
          fill: false,
          tension: 0.4
        }]
      },
      options: {
        plugins: { legend: { display: false } },
        scales: {
          y: { display: false, grid: { display: false }, ticks: { display: false } },
          x: { display: true, grid: { display: false }, ticks: { display: true } }
        }
      }
    });

    historicalEnergyChart = new Chart(energyCtx, {
      type: "bar",
      data: {
        labels: labels,
        datasets: [{
          label: "Energy (kWh)",
          data: energyData,
          backgroundColor: "#007bff"
        }]
      },
      options: {
        plugins: { legend: { display: false } },
        scales: {
          y: { display: false, grid: { display: false }, ticks: { display: false } },
          x: { display: true, grid: { display: false }, ticks: { display: true } }
        }
      }
    });

    const latestPower = powerData[powerData.length - 1];
    const latestEnergy = energyData[energyData.length - 1];

    document.getElementById("histPowerValue").textContent = `${latestPower} kW`;
    document.getElementById("histPowerChange").textContent = `Today`;
    document.getElementById("histEnergyValue").textContent = `${latestEnergy} kWh`;
    document.getElementById("histEnergyChange").textContent = `Today`;

  } catch (error) {
    console.error("Error fetching historical data:", error);
  }
}

window.onload = function () {
  const powerCtx = document.getElementById('powerChart').getContext('2d');
  const energyCtx = document.getElementById('energyChart').getContext('2d');

  powerChart = new Chart(powerCtx, {
    type: 'line',
    data: {
      labels: [], // هيتملوا من الحساس
      datasets: [{ data: [], borderColor: '#007bff', tension: 0.4, fill: false }]
    },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        y: { display: false, grid: { display: false }, ticks: { display: false } },
        x: { display: true, grid: { display: false }, ticks: { display: true } }
      }
    }
  });

  energyChart = new Chart(energyCtx, {
    type: 'bar',
    data: {
      labels: [], // هيتملوا من الحساس
      datasets: [{ data: [], backgroundColor: '#007bff' }]
    },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        y: { display: false, grid: { display: false }, ticks: { display: false } },
        x: { display: true, grid: { display: false }, ticks: { display: true } }
      }
    }
  });

  const activeTab = document.querySelector('.tab.active');
  const underline = document.querySelector('.tabs-underline');
  underline.style.width = activeTab.offsetWidth + 'px';
  underline.style.left = activeTab.offsetLeft + 'px';

  // setInterval(fetchLiveData, 5000);
  // fetchLiveData();
};
